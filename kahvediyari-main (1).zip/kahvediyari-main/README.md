Hello everyone! This is a kahvediyari.com.tr clone that includes most of tabs and little bit of resposive design :) I hope you'll like it!

p.s. I want to thanks a lot to @Barbaros Ciga(barbaros_cg) a.k.a Master Yoda to teach me how to design websites properly :)
